YACRSControl 0.3 
Copyright University of Glasgow, 2014. 
Written by Niall S F Barr, niall.barr@glasgow.ac.uk 

YACRSControl requires the .NET framework version 2.0 or later. It has been tested on Windows XP (sp3) 32 bit and Windows 7 64 bit, and I have no reason to believe it will not run on other x86 versions of windows from XP sp3 onwards. It will not run on Windows RT or Windows Phone versions.

I have also tested it using the Mono framework on Linux (Ubuntu 12.04 desktop) and Mac (OSX Maverick). The Windows version only partially works on these systems, and it is not recomended you try it.

To run YACRS control you need to connect to a Web server running YACRS. The dialog box to log in appears as soon as you run the program. 

For University of Glasgow staff and Postgraduate (Research) students:
* The server URL is https://learn.gla.ac.uk/yacrs/ (this has to be typed with the https:// prefix and the trailing / at the moment - I'll make it more forgiving before the version 1.0 release.) 
* Login using your GUID